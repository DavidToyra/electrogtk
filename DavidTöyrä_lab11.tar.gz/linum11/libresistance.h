#include <stdio.h>
#include <stdlib.h>
float calc_resistance(int count, char conn, float *array);
