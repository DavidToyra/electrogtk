#ifndef _LIBCOMPONENT_H
#define _LIBCOMPONENT_H
    int e_resistance(float orig_resistance, float *res_array);
#endif
