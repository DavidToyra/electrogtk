Programmet använder sig av biblikteken från uppgift 6 och dessa antas finnas i /usr/local/lib
Den är snarlik den textbaserade electrotest från uppgift 6 men denna har ett grafiskt gränssnitt som använder
GTK+ 2.0 (rekommendation från kursboken). Kompileras med make all som skapar den körbara filen electrotestgtk.
