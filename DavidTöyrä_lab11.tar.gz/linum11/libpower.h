#ifndef _LIBPOWER_H_
#define _LIBPOWER_H_

float calc_power_r(float voltage, float resistance);
float calc_power_i(float voltage, float current);

#endif
